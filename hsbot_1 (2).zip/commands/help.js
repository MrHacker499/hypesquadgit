function sleep(ms) {
    return new Promise((resolve, reject) => {
        setTimeout(resolve, ms);
    });
}
module.exports = {
    description: "View this document",
    name: "help",
    run: async (msg, other) => {
        var mess = await msg.channel.send("<a:loading:393852367751086090> Loading...");
        await sleep(5000);
        var message = `**HypeSquad help**\nAvailable commands:\n\`play\` - Play music\n\`stop\` - Stop playback\n`;
        for (var i in other.commands) {
            var c = other.commands[i];
            message = `${message}\`${c.name}\` - ${c.description}\n`;
        }
        mess.edit("Look into your DMs");
        msg.author.send(message);
    }
};