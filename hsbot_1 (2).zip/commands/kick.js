module.exports = {
    description: "Kick people",
    name: "kick",
    run: async (msg, other) => {
        var users = msg.mentions.users.array();
        if (!msg.member.permissions.has("KICK_MEMBERS"))
            return msg.channel.send(":x: Permission denied");
        if (users.length < 1)
            return msg.channel.send("You havent decided who to kick!");

        for (var i=0;i<users.length;i++)
            await msg.guild.members.get(users[i].id).kick();

        msg.channel.send("Done");
    }
};