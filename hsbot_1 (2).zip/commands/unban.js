module.exports = {
    description: "Remove a ban",
    name: "unban",
    run: async (msg, other) => {
        var users = msg.mentions.users.array();
        if (!msg.member.permissions.has("BAN_MEMBERS"))
            return msg.channel.send(":x: Permission denied");

        var code = msg.content.replace(msg.content.split(/\s/)[0], '');
        code = code.substring(1);
        var ids = code.split(" ");
        for (var i=0;i<ids.length;i++) {
            await msg.guild.unban(ids[i]);
        }

        msg.channel.send("Done");
    }
};