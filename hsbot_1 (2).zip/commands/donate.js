module.exports = {
    description: "Donate to the bot",
    name: "donate",
    run: async (msg, other) => {
        msg.author.send("https://www.patreon.com/hypesquad");
    }
};