module.exports = {
    description: "Deploy the Banne hammer",
    name: "ban",
    run: async (msg, other) => {
        var users = msg.mentions.users.array();
        if (!msg.member.permissions.has("BAN_MEMBERS"))
            return msg.channel.send(":x: Permission denied");
        if (users.length < 1)
            return msg.channel.send("You havent decided who to ban!");

        for (var i=0;i<users.length;i++)
            await msg.guild.members.get(users[i].id).ban();

        msg.channel.send("Done");
    }
};