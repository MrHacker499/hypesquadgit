const { RichEmbed } = require('discord.js');
const os = require('os');
function parseTime(seconds) {
    var days = Math.floor(seconds / 86400);
    seconds = seconds - (days * 86400);
    var hours = Math.floor(seconds / 3600);
    seconds = seconds - (hours * 3600);
    var minutes = Math.floor(seconds / 60);
    seconds = seconds - (minutes * 60);
    seconds = Math.floor(seconds);
    return "".concat(days).concat(" days ").concat(hours).concat(" hours ").concat(minutes).concat(" minutes ").concat(seconds).concat(" seconds");
}
function parseMemFromBytes(bytes) {
    var gb = Math.floor(bytes / 1000000000);
    bytes = bytes - (gb * 1000000000);
    var mb = Math.floor(bytes / 1000000);
    return "".concat(gb).concat(".").concat(Math.floor(mb / 10)).concat(" GB");
}
module.exports = {
    description: "View stats about the bot",
    name: "stats",
    run: async (msg, other) => {
        var message = await msg.channel.send("Collecting stats");
        var embed = new RichEmbed();
        embed.setAuthor('HypeSquad Bot');
        embed.setColor('#101010');
        embed.setDescription("Details about the bot");
        embed.setTimestamp(new Date().toISOString());
        embed.addField("Uptime", parseTime(process.uptime()));
        embed.addField("OS", os.type().concat(" ").concat(os.release()));
        embed.addField("CPU", os.cpus()[0].model.concat(" x").concat(os.cpus().length));
        embed.addField("Memory usage", parseMemFromBytes(os.totalmem() - os.freemem()).concat(" / ").concat(parseMemFromBytes(os.totalmem())));
        await message.edit("", {embed: embed});
    }
};