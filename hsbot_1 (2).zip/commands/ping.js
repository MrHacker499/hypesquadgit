module.exports = {
    description: "Check all sorts of latencies",
    name: "ping",
    run: async (msg, other) => {
        var pretime = process.uptime();
        var message = await msg.channel.send(`Heartbeat ping: ${other.client.ping}`);
        var time = process.uptime();
        await message.edit(`Heartbeat ping: ${Math.floor(other.client.ping)} | Message ping: ${Math.floor((time - pretime) * 1000)}`);
    }
};