const { inspect } = require('util');
module.exports = {
    description: "Execute JavaScript code",
    name: "eval",
    run: async (msg, other) => {
        if (!(msg.author.id === '102038103463567360')) return msg.channel.send(":x: Permission denied!");
        var code = msg.content.replace(msg.content.split(/\s/)[0], '');
        try {
            var result = eval(code);
            msg.channel.send("Evaluation results:");
            msg.channel.send(inspect(result, { compact: false, depth: 0} ), {code:"javascript", split:true});
        } catch(e) {
            msg.channel.send("Evaluation error:");
            msg.channel.send(inspect(e, { compact: false, depth: 0} ), {code:"javascript", split:true});
        }
    }
};