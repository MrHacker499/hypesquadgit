const { Client } = require('discord.js');
const sqlite = require('sqlite');
const prefix = "!";
const fs = require('fs-extra');
const { token } = require('./login.json');

var commands = {};

(async function run() {
    console.log("Welcome");
    const client = new Client();
    await client.login(token);
    console.log("Connected to discord");
    await client.user.setPresence({
        status: 'online',
        game: {
            name: '!help|discord.gg/sd9MJXx',
            type: 'STREAMING'
        }
    });
    console.log("Loading commands");
    var files = await fs.readdir('commands');
    files.forEach(f => {
        var command = require(('./commands/' + f).split('.js')[0]);
        commands[command.name] = command;
    });

    console.log("Defining events");
    client.on('message', async (msg) => {
        if (msg.author.bot) return;
        if (!msg.content.startsWith(prefix)) return;
        var command = msg.content.split(prefix)[1].split(" ")[0];
        if (commands[command])
            await commands[command].run(msg, {
                client: client,
                commands: commands
            });
    });
})();